﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XLabs.Test.NuGet.Profile259
{
    public class Class1
    {
    }
}
